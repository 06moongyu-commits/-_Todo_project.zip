# To-do List Web App — PRD (Markdown Version)

## 1. Overview

### 목적
브라우저 기반으로 동작하며 백엔드 없이 LocalStorage만으로 데이터를 저장·관리하는 To-do List 웹 애플리케이션을 개발한다. 필수 기능은 CRUD, 필터링, 정렬, 알림이며 HTML/CSS/JavaScript의 순수 프론트엔드 스택을 사용한다.

### 기술 스택
- HTML
- CSS
- JavaScript (Vanilla)
- LocalStorage
- 배포(옵션): GitHub Pages, Netlify

## 2. Requirements

### 2.1 User Stories
- 사용자는 할 일을 추가할 수 있어야 한다.
- 사용자는 기존의 할 일을 수정할 수 있어야 한다.
- 사용자는 할 일을 삭제할 수 있어야 한다.
- 사용자는 할 일 완료 상태를 체크할 수 있다.
- 사용자는 완료/미완료 기준으로 필터링할 수 있다.
- 사용자는 생성일, 마감일, 제목 기준으로 정렬할 수 있다.
- 사용자는 마감 시간에 알림(Notification)을 받을 수 있다.
- 사용자는 새로고침해도 데이터가 유지되기를 원한다(LocalStorage).

## 3. Functional Requirements

### 3.1 To-do CRUD

#### Create
- 입력값: title(필수), description(선택), dueDate(선택)
- “추가” 버튼 클릭 시 LocalStorage에 저장
- 데이터 구조:
```json
{
  "id": "uuid",
  "title": "Todo Title",
  "description": "Optional detail",
  "dueDate": "2025-05-10T18:00",
  "createdAt": "2025-05-09T10:12",
  "completed": false
}
```

#### Read
- LocalStorage에서 데이터를 불러와 UI에 렌더링
- 필터 및 정렬 조건 반영

#### Update
- 수정 UI 제공
- 수정 후 LocalStorage 업데이트

#### Delete
- 삭제 확인 후 LocalStorage에서 제거

### 3.2 Filter
- 전체(All)
- 완료(Completed)
- 미완료(Incomplete)

### 3.3 Sort
- 생성일 오름차순/내림차순
- 마감일 오름차순/내림차순
- 제목 가나다순

### 3.4 Notification
- dueDate가 설정된 항목에 대해 알림 제공
- Notification API 활용
- setInterval로 주기적 마감 체크
- Fallback: alert

### 3.5 LocalStorage
- Key: todoList
- CRUD 작업 시마다 즉시 저장

## 4. Non-functional Requirements

### 성능
- 500개까지 부드럽게 동작
- 렌더링 시간 3초 이하

### UX
- 모바일/데스크탑 반응형
- 완료 항목 흐리게 + 취소선
- 마감 시간 지나면 강조 표시

### 유지보수
- JS 모듈 구조 분리

## 5. Technical Design

### Directory Structure
```
/
|-- index.html
|-- style.css
|-- app.js
|-- data.js
|-- ui.js
```

### 주요 함수
- loadTodos()
- saveTodos()
- addTodo()
- updateTodo()
- deleteTodo()
- renderList()
- applyFilter()
- applySort()
- checkDueDates()

## 6. UI Specification

### 화면 구성
- Header: 앱 제목, 테마 전환(옵션)
- Input Form: title / description / dueDate / 추가 버튼
- Todo List: 체크박스, 제목, 설명, 마감일, 수정/삭제
- Footer: 필터 및 정렬 메뉴

## 7. Test Cases

### 기능 테스트
- CRUD 정상 동작
- 필터/정렬 정상 적용
- 알림 정상 동작
- 새로고침 후 데이터 유지

## 8. 향후 확장 기능
- Drag & Drop
- 태그 기능
- 완료율 통계
- PWA 지원
